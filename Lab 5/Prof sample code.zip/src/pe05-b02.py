import carlib



def main():
    
    toyotaCorolla = carlib.Car('Toyota', 'Corolla', 4)
    
    print(toyotaCorolla.toString())
    
    toyotaCorolla.startEngine()
    print(toyotaCorolla.toString())
    print('Current motion {} m {} sec at speed {:.3f} km/h'.format(300,20,toyotaCorolla.addMotion(300, 20)))
    print('Current motion {} m {} sec at speed {:.3f} km/h'.format(300,40,toyotaCorolla.addMotion(300, 40)))
    print('Current motion {} m {} sec at speed {:.3f} km/h'.format(300,60,toyotaCorolla.addMotion(300, 60)))
    print('Current motion {} m {} sec at speed {:.3f} km/h'.format(1000,300,toyotaCorolla.addMotion(1000, 300)))    
    toyotaCorolla.stopEngine()
    
    print(toyotaCorolla.toString())
    print('Travel Time = {:.3f} min'.format(toyotaCorolla.computeCurrentTripTravelTimeInMinute()))
    print('Total Distance = {:.3f} km'.format(toyotaCorolla.computeCurrentTripTotalDistanceInKm()))
    print('Average Speed = {:.3f} km/h'.format(toyotaCorolla.computeCurrentTripAverageSpeedInKmPerHour()))



if __name__ == '__main__':
    
    main()
