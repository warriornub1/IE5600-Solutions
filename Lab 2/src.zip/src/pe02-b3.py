is_palindrome = True

word = input('Enter a word of at most 5 alphabets: ')
word = word.strip().lower()
length = len(word)

if length == 0:

    print('You did not input a word')

elif length > 5:
    
    print('The word has more than 5 alphabets')

else:

    if length == 2:
        
        if word[0] != word[1]:
            is_palindrome = False
        
    elif length == 3:
        
        if word[0] != word[2]:
            is_palindrome = False
    
    elif length == 4:
        
        if (word[0] != word[3]) or (word[1] != word[2]):
            is_palindrome = False
    
    elif length == 5:
        
        if (word[0] != word[4]) or (word[1] != word[3]):
            is_palindrome = False
    
    if is_palindrome:
        
        print('{} is a palindrome'.format(word))
    
    else:
        
        print('{} is not a palindrome'.format(word))
