char1 = input('Enter an alphabet: ')
char1 = char1.strip().upper()

if char1 in ('A', 'B', 'C'):
    
    print('You have entered one of the first three English alphabets')

else:
    
    print('You have entered other English alphabets')

if char1 not in ('A', 'B', 'C'):
    
    print('You have entered other English alphabets')

else:
    
    print('You have entered one of the first three English alphabets')



# for question b4, we can re-write the following if statement:
# if nric[0] == 'S' or nric[0] == 'T' or nric[0] == 'F' or nric[0] == 'G':
#
# using the in operator
#
# if nric[0] in ('S', 'T', 'F', 'G')
